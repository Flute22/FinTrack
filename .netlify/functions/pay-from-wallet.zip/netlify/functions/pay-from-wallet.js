var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/pay-from-wallet.js
var pay_from_wallet_exports = {};
__export(pay_from_wallet_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(pay_from_wallet_exports);
var import_crypto = __toESM(require("crypto"), 1);
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
async function verifySupabaseUser(authHeader) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { Authorization: `Bearer ${token}`, apikey: SUPABASE_SERVICE_KEY }
  });
  if (!res.ok) return null;
  const user = await res.json();
  return user?.id || null;
}
async function sbQuery(path, method = "GET", body) {
  const opts = {
    method,
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_SERVICE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_KEY}`,
      Prefer: "return=representation"
    }
  };
  if (body) opts.body = JSON.stringify(body);
  return fetch(`${SUPABASE_URL}/rest/v1/${path}`, opts);
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST")
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: "Method not allowed" }) };
  try {
    const userId = await verifySupabaseUser(event.headers.authorization);
    if (!userId)
      return { statusCode: 401, headers: cors, body: JSON.stringify({ error: "Unauthorized" }) };
    const { amount, upi_id, description } = JSON.parse(event.body);
    const amountNum = Number(amount);
    if (!amountNum || amountNum < 1 || amountNum > 99999)
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "Amount must be between \u20B91 and \u20B999,999" }) };
    const upiClean = String(upi_id || "").trim().toLowerCase().slice(0, 100);
    if (!upiClean || !/^[\w.\-]+@[\w.\-]+$/.test(upiClean))
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "Invalid UPI ID format. Use: name@upi" }) };
    const descClean = String(description || "").trim().replace(/[<>]/g, "").slice(0, 100);
    const since60s = new Date(Date.now() - 6e4).toISOString();
    const recentRes = await sbQuery(
      `wallet_transactions?user_id=eq.${userId}&type=eq.debit&created_at=gte.${since60s}&select=id`
    );
    const recentRows = await recentRes.json();
    if (Array.isArray(recentRows) && recentRows.length >= 5)
      return { statusCode: 429, headers: cors, body: JSON.stringify({ error: "Too many payment requests. Please wait a moment." }) };
    const since15s = new Date(Date.now() - 15e3).toISOString();
    const dupRes = await sbQuery(
      `wallet_transactions?user_id=eq.${userId}&type=eq.debit&amount=eq.${amountNum}&created_at=gte.${since15s}&select=id,razorpay_payment_id`
    );
    const dupRows = await dupRes.json();
    if (Array.isArray(dupRows) && dupRows.length > 0)
      return {
        statusCode: 200,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({ success: true, amount: amountNum, tx_ref: dupRows[0].razorpay_payment_id, reused: true })
      };
    const walletRes = await sbQuery(`wallet?user_id=eq.${userId}`);
    const walletRows = await walletRes.json();
    const currentBalance = walletRows?.[0] ? Number(walletRows[0].balance) : 0;
    if (currentBalance < amountNum)
      return {
        statusCode: 400,
        headers: cors,
        body: JSON.stringify({ error: `Insufficient balance. Available: \u20B9${currentBalance.toLocaleString("en-IN")}` })
      };
    const newBalance = currentBalance - amountNum;
    const txId = `wt_pay_${Date.now()}_${import_crypto.default.randomBytes(4).toString("hex")}`;
    const txRef = `PAY${Date.now().toString(36).toUpperCase()}`;
    await Promise.all([
      sbQuery(`wallet?user_id=eq.${userId}`, "PATCH", { balance: newBalance, updated_at: (/* @__PURE__ */ new Date()).toISOString() }),
      sbQuery("wallet_transactions", "POST", {
        id: txId,
        user_id: userId,
        amount: amountNum,
        type: "debit",
        status: "completed",
        razorpay_payment_id: txRef,
        description: `To ${upiClean}${descClean ? ` \xB7 ${descClean}` : ""}`,
        verified_at: (/* @__PURE__ */ new Date()).toISOString()
      })
    ]);
    return {
      statusCode: 200,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ success: true, amount: amountNum, new_balance: newBalance, tx_ref: txRef })
    };
  } catch {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: "Server error" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
