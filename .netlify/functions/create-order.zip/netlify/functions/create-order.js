var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/create-order.js
var create_order_exports = {};
__export(create_order_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(create_order_exports);
var import_crypto = __toESM(require("crypto"), 1);
var RAZORPAY_KEY_ID = process.env.RAZORPAY_KEY_ID;
var RAZORPAY_KEY_SECRET = process.env.RAZORPAY_KEY_SECRET;
var SUPABASE_URL = process.env.SUPABASE_URL;
var SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY;
var cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Allow-Methods": "POST, OPTIONS"
};
async function verifySupabaseUser(authHeader) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  const res = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { Authorization: `Bearer ${token}`, apikey: SUPABASE_SERVICE_KEY }
  });
  if (!res.ok) return null;
  const user = await res.json();
  return user?.id || null;
}
async function sbGet(path) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: { apikey: SUPABASE_SERVICE_KEY, Authorization: `Bearer ${SUPABASE_SERVICE_KEY}` }
  });
  return res.json();
}
async function sbPost(path, body) {
  return fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: SUPABASE_SERVICE_KEY,
      Authorization: `Bearer ${SUPABASE_SERVICE_KEY}`,
      Prefer: "return=minimal"
    },
    body: JSON.stringify(body)
  });
}
async function handler(event) {
  if (event.httpMethod === "OPTIONS") return { statusCode: 204, headers: cors };
  if (event.httpMethod !== "POST")
    return { statusCode: 405, headers: cors, body: JSON.stringify({ error: "Method not allowed" }) };
  if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET)
    return { statusCode: 503, headers: cors, body: JSON.stringify({ error: "Payment gateway not configured." }) };
  try {
    const userId = await verifySupabaseUser(event.headers.authorization);
    if (!userId)
      return { statusCode: 401, headers: cors, body: JSON.stringify({ error: "Unauthorized" }) };
    const { amount } = JSON.parse(event.body);
    const amountNum = Number(amount);
    if (!amountNum || amountNum < 1 || amountNum > 99999)
      return { statusCode: 400, headers: cors, body: JSON.stringify({ error: "Amount must be between \u20B91 and \u20B999,999" }) };
    const amountPaise = Math.round(amountNum * 100);
    const since60s = new Date(Date.now() - 6e4).toISOString();
    const since15s = new Date(Date.now() - 15e3).toISOString();
    const recentAll = await sbGet(
      `wallet_transactions?user_id=eq.${userId}&status=eq.pending&created_at=gte.${since60s}&select=id`
    );
    if (Array.isArray(recentAll) && recentAll.length >= 5)
      return { statusCode: 429, headers: cors, body: JSON.stringify({ error: "Too many requests. Please wait a moment and try again." }) };
    const recentDup = await sbGet(
      `wallet_transactions?user_id=eq.${userId}&status=eq.pending&amount=eq.${amountNum}&created_at=gte.${since15s}&select=id,razorpay_order_id`
    );
    if (Array.isArray(recentDup) && recentDup.length > 0 && recentDup[0].razorpay_order_id) {
      return {
        statusCode: 200,
        headers: { ...cors, "Content-Type": "application/json" },
        body: JSON.stringify({
          order_id: recentDup[0].razorpay_order_id,
          amount: amountPaise,
          currency: "INR",
          tx_id: recentDup[0].id,
          reused: true
        })
      };
    }
    const receiptId = `rcpt_${userId.slice(0, 8)}_${Date.now()}`;
    const auth = Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString("base64");
    const rzpRes = await fetch("https://api.razorpay.com/v1/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Basic ${auth}` },
      body: JSON.stringify({ amount: amountPaise, currency: "INR", receipt: receiptId, notes: { user_id: userId } })
    });
    if (!rzpRes.ok)
      return { statusCode: 502, headers: cors, body: JSON.stringify({ error: "Payment gateway error. Please try again." }) };
    const order = await rzpRes.json();
    const txId = `wt_${Date.now()}_${import_crypto.default.randomBytes(4).toString("hex")}`;
    await sbPost("wallet_transactions", {
      id: txId,
      user_id: userId,
      amount: amountNum,
      type: "credit",
      status: "pending",
      razorpay_order_id: order.id
    });
    return {
      statusCode: 200,
      headers: { ...cors, "Content-Type": "application/json" },
      body: JSON.stringify({ order_id: order.id, amount: amountPaise, currency: "INR", tx_id: txId })
    };
  } catch {
    return { statusCode: 500, headers: cors, body: JSON.stringify({ error: "Server error" }) };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
